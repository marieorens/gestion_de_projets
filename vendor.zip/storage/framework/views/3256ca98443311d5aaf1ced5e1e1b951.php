

<?php $__env->startSection('content'); ?>
    <div class="container mx-auto p-6 bg-white shadow rounded">
          <marquee behavior="scroll" direction="feft"><h1 class="text-3xl font-bold mb-6 text-gray-800">Bienvenue dans votre centre de notifications</h1></marquee>

        <?php if($tasks->isEmpty()): ?>
            <p class="text-gray-600">Aucune tâche assignée pour le moment.</p>
        <?php else: ?>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="p-4 bg-gray-100 rounded shadow hover:shadow-lg transition duration-300">
                        <h2 class="text-xl font-semibold text-blue-600"><?php echo e($task->title); ?></h2>
                        <p class="text-sm text-gray-500 mb-2"><?php echo e($task->description ?? 'Aucune description'); ?></p>
                        <div class="text-sm text-gray-600 space-y-1">
                            <p><strong>Statut :</strong> 
                                <span class="px-2 py-1 rounded text-white 
                                    <?php echo e($task->status == 'non commencé' ? 'bg-red-500' : ($task->status == 'en cours' ? 'bg-yellow-500' : 'bg-green-500')); ?>">
                                    <?php echo e(ucfirst($task->status)); ?>

                                </span>
                            </p>
                            <p><strong>Priorité :</strong> <?php echo e(ucfirst($task->priority)); ?></p>
                            <p><strong>Projet :</strong> <?php echo e($task->project->title ?? 'Non associé à un projet'); ?></p>
                        </div><br>
                        <?php if($task->project): ?>
                            <a href="<?php echo e(route('projects.show', $task->project->id)); ?>" 
                            class="bg-green-500 px-3 py-1 rounded">
                                Voir le projet
                            </a>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Setups\gestiontaches\resources\views/notifications/index.blade.php ENDPATH**/ ?>