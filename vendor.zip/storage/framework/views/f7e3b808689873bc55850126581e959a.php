<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($pageTitle ?? 'Gestion de Tâches'); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <?php echo $__env->yieldContent('styles'); ?>
</head>
<body class="bg-gray-100">
    <nav class="bg-blue-600 text-white p-4">
        <div class="container mx-auto flex justify-between items-center">
            <a href="<?php echo e(route('dashboard')); ?>" class="text-xl font-bold">Gestion de Tâches</a>
            <div>
                <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(route('projects.index')); ?>" class="bg-green-500 px-3 py-1 rounded"> Mes Projets</a><br><br>
                    <a href="<?php echo e(route('admin.projets-utilisateurs')); ?>" class="bg-green-500 px-3 py-1 rounded">Gestion des Utilisateurs</a><br><br>
                    <a href="<?php echo e(route('notifications.index')); ?>" class="bg-green-500 px-3 py-1 rounded">Mes notifications</a><br><br>
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                      <?php echo csrf_field(); ?>
                      <button type="submit" class="bg-red-500 px-3 py-1 rounded">Déconnexion</button>
                    </form>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>" class="mr-4">Connexion</a>
                    <a href="<?php echo e(route('register')); ?>" class="bg-green-500 px-3 py-1 rounded">S'inscrire</a>
                <?php endif; ?>
            </div>
        </div>
    </nav><br>

    <div class="grid grid-cols-3 gap-4">

        <div class="bg-blue-100 p-4 rounded">
            <h2 class="text-xl">Projets en cours</h2>
            <p class="text-4xl font-bold"><?php echo e($ongoingProjects); ?></p>
        </div>

       
        <div class="bg-green-100 p-4 rounded">
            <h2 class="text-xl">Tâches terminées</h2>
            <p class="text-4xl font-bold"><?php echo e($completedTasks); ?></p>
        </div>

       
        <div class="bg-yellow-100 p-4 rounded">
            <h2 class="text-xl">Tâches en cours</h2>
            <p class="text-4xl font-bold"><?php echo e($inProgressTasks); ?></p>
        </div>
    </div>


    <div class="mt-8">
        <h2 class="text-2xl mb-4">Mes Projets Récents</h2>

        
        <?php $__currentLoopData = $recentProjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-gray-50 p-4 mb-4 rounded flex justify-between items-center">
                <div>
                    <h3 class="text-lg font-bold"><?php echo e($project->title); ?></h3>
                    <p><?php echo e($project->description); ?></p>
                </div>
                <div>
                    <span class="badge <?php echo e($project->status == 'en cours' ? 'bg-yellow-200' : 'bg-green-200'); ?>">
                        <?php echo e($project->status); ?>

                    </span>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    

        

    <main class="container mx-auto mt-6 p-4">
        <?php echo $__env->yieldContent('content'); ?>
    </main>
   
    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\Setups\gestiontaches\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>