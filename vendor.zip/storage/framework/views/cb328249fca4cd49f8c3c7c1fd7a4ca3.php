<?php $__env->startSection('content'); ?>
<div class="bg-white p-6 rounded shadow">
    <div class="mb-6">
        <h1 class="text-3xl"><?php echo e($project->title); ?></h1>
        <p class="text-gray-600"><?php echo e($project->description); ?></p>
    </div>

    <div class="mb-6">
        <h2 class="text-2xl mb-4">Tâches du Projet</h2>
        <?php $__currentLoopData = $project->tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-gray-50 p-4 mb-3 rounded flex justify-between items-center">
                <div>
                    <h3 class="font-bold"><?php echo e($task->title); ?></h3>
                    <p><?php echo e($task->description); ?></p>
                </div>
                <div class="flex items-center">
                    <span class="mr-4 badge 
                        <?php echo e($task->status == 'non commencé' ? 'bg-red-200' : 
                           ($task->status == 'en cours' ? 'bg-yellow-200' : 'bg-green-200')); ?>">
                        <?php echo e($task->status); ?>

                    </span>
                    <span class="mr-4">Priorité: <?php echo e($task->priority); ?></span>
                    <span>Assigné à: <?php echo e($task->assignedUser ? $task->assignedUser->name : 'Non assigné'); ?></span>

                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Setups\gestiontaches\resources\views/projects/show.blade.php ENDPATH**/ ?>