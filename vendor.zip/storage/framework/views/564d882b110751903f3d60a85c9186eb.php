<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($pageTitle ?? 'Gestion de Tâches'); ?></title>
    <!-- Tailwind CSS for styling -->
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <?php echo $__env->yieldContent('styles'); ?>
</head>
<body class="bg-gray-100">
    <nav class="bg-blue-600 text-white p-4">
        <div class="container mx-auto flex justify-between items-center">
            <a href="<?php echo e(route('dashboard')); ?>" class="text-xl font-bold">Gestion de Tâches</a>
            <div>
                <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(route('projects.index')); ?>" class="bg-green-500 px-3 py-1 rounded">Mes Projets</a><br><br>

                    <a href="<?php echo e(route('notifications.index')); ?>" class="bg-green-500 px-3 py-1 rounded">Mes notifications</a><br><br>

                    <?php if(auth()->user()->role === 'admin'): ?>
                        <a href="<?php echo e(route('admin.projets-utilisateurs')); ?>" class="bg-green-500 px-3 py-1 rounded">Gestion des Utilisateurs</a><br><br>
                    <?php endif; ?>
                    
                    <a href="<?php echo e(route('logout')); ?>" class="bg-red-500 px-3 py-1 rounded">Déconnexion</a>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>" class="mr-4">Connexion</a>
                    <a href="<?php echo e(route('register')); ?>" class="bg-green-500 px-3 py-1 rounded">S'inscrire</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <main class="container mx-auto mt-6 p-4">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html><?php /**PATH C:\Setups\gestiontaches\resources\views/layouts/app.blade.php ENDPATH**/ ?>