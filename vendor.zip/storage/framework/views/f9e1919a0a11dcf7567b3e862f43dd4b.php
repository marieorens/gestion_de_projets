<?php $__env->startSection('content'); ?>
<div class="bg-white p-6 rounded shadow">
    <h1 class="text-3xl mb-6">Tableau de Bord</h1>
   
    
    <div class="grid grid-cols-3 gap-4">
        <div class="bg-blue-100 p-4 rounded">
            <h2 class="text-xl">Projets en cours</h2>
            <p class="text-4xl font-bold"><?php echo e($ongoingProjects); ?></p>
        </div>
        <div class="bg-green-100 p-4 rounded">
            <h2 class="text-xl">Tâches terminées</h2>
            <p class="text-4xl font-bold"><?php echo e($completedTasks); ?></p>
        </div>
        <div class="bg-yellow-100 p-4 rounded">
            <h2 class="text-xl">Tâches en cours</h2>
            <p class="text-4xl font-bold"><?php echo e($inProgressTasks); ?></p>
        </div>
    </div>

    <div class="mt-8">
        <h2 class="text-2xl mb-4">Mes Projets Récents</h2>
        <?php $__currentLoopData = $recentProjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-gray-50 p-4 mb-4 rounded flex justify-between items-center">
                <div>
                    <h3 class="text-lg font-bold"><?php echo e($project->title); ?></h3>
                    <p><?php echo e($project->description); ?></p>
                </div>
                <div>
                    <span class="badge <?php echo e($project->status == 'en cours' ? 'bg-yellow-200' : 'bg-green-200'); ?>">
                        <?php echo e($project->status); ?>

                    </span>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Setups\gestiontaches\resources\views/dashboard.blade.php ENDPATH**/ ?>