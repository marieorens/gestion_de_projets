<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des utilisateurs et projets</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">

    <div class="container mx-auto p-4">
       <marquee behavior="scroll" direction="left"><h1 class="text-2xl font-bold mb-4">Gestion des utilisateurs et projets</h1></marquee><br><br>

        
        <table class="table-auto w-full bg-white shadow-lg rounded-lg">
            <thead>
                <tr class="bg-gray-200">
                    <th class="border p-2 text-left">Nom</th>
                    <th class="border p-2 text-left">Email</th>
                    <th class="border p-2 text-left">Projets</th>
                    <th class="border p-2 text-left">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-b">
                        <td class="border p-2"><?php echo e($user->name); ?></td>
                        <td class="border p-2"><?php echo e($user->email); ?></td>
                        <td class="border p-2">
                            <?php if($user->projects->isEmpty()): ?>
                                <p>Aucun projet</p>
                            <?php else: ?>
                                <ul>
                                    <?php $__currentLoopData = $user->projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="mb-2">
                                            <?php echo e($project->title); ?>

                                            <div class="inline-flex space-x-2 ml-2">
                                                <a href="<?php echo e(route('admin.edit_project', $project->id)); ?>" 
                                                   class="text-blue-500 hover:underline">Modifier</a>
                                                <form action="<?php echo e(route('admin.delete_project', $project->id)); ?>" method="POST" class="inline-block">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="text-red-500 hover:underline">Supprimer</button>
                                                </form>
                                            </div>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php endif; ?>
                        </td>
                        <td class="border p-2">
                            <div class="flex flex-col space-y-2">
                                <a href="<?php echo e(route('admin.create_project', $user->id)); ?>" 
                                   class="bg-green-500 text-white px-3 py-1 rounded hover:bg-green-600">
                                   Créer Projet
                                </a>
                                <a href="<?php echo e(route('admin.edit_user', $user->id)); ?>" 
                                   class="bg-blue-500 text-white px-3 py-1 rounded hover:bg-blue-600">
                                   Modifier Utilisateur
                                </a>
                                <form action="<?php echo e(route('admin.delete_user', $user->id)); ?>" method="POST" class="inline-block">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" 
                                            class="bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600">
                                        Supprimer Utilisateur
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

</body>
</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Setups\gestiontaches\resources\views/admin/projets-utilisateurs.blade.php ENDPATH**/ ?>